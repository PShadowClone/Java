package net.ucanaccess.jdbc;

import org.hsqldb.error.ErrorCode;

public interface UcanaccessErrorCodes extends ErrorCode {
	public final static int UCANACCESS_GENERIC_ERROR=15000;//Ucanaccess Error
}
